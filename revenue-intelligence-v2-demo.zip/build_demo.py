"""Build a public portfolio demo from independent synthetic data. Python 3, stdlib only.

Run: python build_demo.py
Never reads a workbook, private export, environment variable, or external service.
"""
from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import html
import json
import random
import zipfile

ROOT = Path(__file__).resolve().parent
MONTHLY_ACTUAL = [72, 64, 86, 92, 100, 114, 123, 135, 174]  # fictional 0.1B VND
MONTHLY_PLAN = [70, 60, 80, 85, 90, 95, 100, 110, 130]
MONTHLY_PRIOR = [60, 58, 72, 75, 80, 90, 100, 115, 130]
INVOICES = [42, 38, 45, 49, 53, 55, 59, 61, 68]
CATEGORIES = [f"Category {x}" for x in "ABCDEF"]
REPS = [f"Representative {x:02}" for x in range(1, 6)]
CATEGORY_PLAN = [25, 19, 13, 11, 8, 6]  # fictional YTD allocation, B VND
FIELDS = ["Period", "Document ID", "Line ID", "Category", "Representative", "Customer group", "Sales excluding VAT", "VAT"]


def create_inputs():
    rng = random.Random(61027)
    sheets = []
    for m, count in enumerate(INVOICES, 1):
        lines = []
        for i in range(count):
            group = rng.choices(range(1, 17), weights=[16, 12, 9, 8] + [5] * 12)[0]
            rep = REPS[(group - 1) % len(REPS)]
            for line in range(1, rng.randint(1, 3) + 1):
                cat = rng.choices(CATEGORIES, weights=[25, 23, 17, 15, 12, 8])[0]
                lines.append({"Period": f"M{m:02}", "Document ID": f"DEMO-{m:02}-{i + 1:03}",
                              "Line ID": f"DEMO-{m:02}-{i + 1:03}-{line}", "Category": cat,
                              "Representative": rep, "Customer group": f"Group {group:02}",
                              "weight": rng.randint(10, 150)})
        units = MONTHLY_ACTUAL[m - 1] * 1000  # units of 100,000 VND
        total_weight = sum(x["weight"] for x in lines)
        allocation = [units * x["weight"] // total_weight for x in lines]
        for i in range(units - sum(allocation)):
            allocation[i % len(allocation)] += 1
        headers = FIELDS[:] if m <= 3 else FIELDS[-2:] + FIELDS[:-2] if m <= 6 else FIELDS[3:] + FIELDS[:3]
        for item, value in zip(lines, allocation):
            item.pop("weight")
            item["Sales excluding VAT"] = value * 100000
            item["VAT"] = value * 8000
        sheets.append({"period": f"M{m:02}", "headers": headers, "rows": [[x[k] for k in headers] for x in lines]})
    return {"notice": "Independently generated fictional demonstration. No private source records or scaled actuals.",
            "unit": "VND", "sheets": sheets,
            "planning_assumptions": {"monthly_budget": [x * 100000000 for x in MONTHLY_PLAN],
                                     "monthly_prior_comparison": [x * 100000000 for x in MONTHLY_PRIOR],
                                     "category_ytd_budget": dict(zip(CATEGORIES, [int(x * 1e9) for x in CATEGORY_PLAN])),
                                     "annual_budget": 120000000000,
                                     "monthly_sales_controls": [x * 100000000 for x in MONTHLY_ACTUAL]}}


def normalize(source):
    records = []
    for sheet in source["sheets"]:
        headers = sheet["headers"]
        if len(headers) != len(set(headers)) or set(headers) != set(FIELDS):
            raise ValueError("Missing, unexpected or duplicate column headers")
        for row in sheet["rows"]:
            if len(row) != len(headers):
                raise ValueError("Row length does not match header schema")
            record = dict(zip(headers, row))
            if any(record[k] is None or record[k] == "" for k in FIELDS):
                raise ValueError("Missing required value")
            if record["Period"] != sheet["period"]:
                raise ValueError("Period does not match source sheet")
            if record["Category"] not in CATEGORIES or record["Representative"] not in REPS:
                raise ValueError("Unmapped category or representative")
            for key in ["Sales excluding VAT", "VAT"]:
                if not isinstance(record[key], int):
                    raise ValueError("Expected integer monetary value")
            records.append(record)
    return records


def aggregate(records, key):
    result = defaultdict(int)
    for r in records:
        result[r[key]] += r["Sales excluding VAT"]
    return dict(result)


def bn(value):
    return f"{value / 1e9:,.1f}"


def pct(value):
    return f"{value:.1%}"


def comparison_assumptions():
    """Independent fictional allocations, not estimates of a private workbook."""
    cells = []
    for i, brand in enumerate(CATEGORIES):
        for j, staff in enumerate(REPS):
            cells.append({"brand": brand, "staff": staff,
                          "prior_2025": [26, 19, 13, 10, 6, 4][i] * [36, 24, 18, 12, 10][j] * 10000000,
                          "budget_2026": [32, 28, 21, 17, 13, 9][i] * [32, 24, 19, 14, 11][j] * 10000000,
                          "target_2026": [48, 42, 32, 26, 19, 13][i] * [29, 23, 20, 16, 12][j] * 10000000})
    return {"annual_target": 180000000000, "comparison_cells": cells}


def display_label(value):
    return value.replace("Category", "Brand").replace("Representative", "Staff")


def comparison_views(cells):
    """Use one staff-brand cube for all plan and year comparisons."""
    keys = ['prior_2025', 'budget_2026', 'target_2026', 'actual_2026']

    def rollup(dimension):
        result = {}
        for cell in cells:
            label = cell[dimension]
            result.setdefault(label, dict.fromkeys(keys, 0))
            for key in keys:
                result[label][key] += cell[key]
        return result

    brands, staff = rollup('brand'), rollup('staff')
    totals = {key: sum(x[key] for x in cells) for key in keys}

    def ratio(numerator, denominator):
        return pct(numerator / denominator) if denominator else 'n.a.'

    def table_row(label, values, total=False):
        actual, prior = values['actual_2026'], values['prior_2025']
        delta = actual - prior
        cls = ' class="total-row"' if total else ''
        trend = 'positive' if delta >= 0 else 'negative'
        return (f'<tr{cls}><th scope="row">{html.escape(display_label(label))}</th>'
                f'<td>{bn(values["target_2026"])}</td><td>{bn(values["budget_2026"])}</td>'
                f'<td>{bn(prior)}</td><td><strong>{bn(actual)}</strong></td>'
                f'<td class="{trend}">{delta / 1e9:+.1f}</td><td class="{trend}">{ratio(delta, prior)}</td>'
                f'<td>{ratio(actual, values["budget_2026"])}</td><td>{ratio(actual, values["target_2026"])}</td></tr>')

    def table(rows, dimension):
        heading = ('<tr><th scope="col">' + dimension + '</th><th scope="col">Target 2026<br>Full year (B)</th>'
                   '<th scope="col">Budget 2026<br>Full year (B)</th><th scope="col">YTD 2025<br>Jan–Sep (B)</th>'
                   '<th scope="col">YTD 2026<br>Jan–Sep (B)</th><th scope="col">YoY Δ<br>(B)</th>'
                   '<th scope="col">YoY Δ<br>(%)</th><th scope="col">FY budget<br>attainment</th><th scope="col">FY target<br>attainment</th></tr>')
        return ('<div class="table-wrap" tabindex="0" role="region" aria-label="Sales comparison by ' + dimension.lower() + '"><table>'
                '<caption>All figures synthetic · B VND · YTD periods aligned to January–September.</caption><thead>' + heading + '</thead><tbody>'
                + ''.join(table_row(label, v) for label, v in rows.items()) + '</tbody><tfoot>' + table_row('Total', totals, True) + '</tfoot></table></div>')

    plan_svg = ['<svg viewBox="0 0 950 220" role="img" aria-labelledby="plan-title plan-desc"><title id="plan-title">Target, budget and actual sales for 2026</title><desc id="plan-desc">Fictional full-year target 180B, full-year budget 120B and January–September actual sales 96B VND. The plans cover twelve months; actuals cover nine.</desc>']
    for i, (label, value, color) in enumerate([('Target 2026 · full year', totals['target_2026'], 'target-bar'), ('Budget 2026 · full year', totals['budget_2026'], 'plan-bar'), ('YTD 2026 · Jan–Sep', totals['actual_2026'], 'actual-bar')]):
        y = 20 + i * 64
        width = value / totals['target_2026'] * 640
        plan_svg.append(f'<text class="axis" x="0" y="{y + 21}">{label}</text><rect class="{color}" x="210" y="{y}" width="{width}" height="32" rx="4"/><text class="bar-label" x="{220 + width}" y="{y + 21}">{bn(value)}B</text>')
    plan_svg.append('</svg>')

    def year_bars(rows):
        maximum = max(max(v['prior_2025'], v['actual_2026']) for v in rows.values())
        result = []
        for label, values in rows.items():
            prior, actual = values['prior_2025'], values['actual_2026']
            result.append(f'<div class="year-item"><div class="year-label"><strong>{display_label(label)}</strong><span class="{"positive" if actual >= prior else "negative"}">{(actual-prior)/1e9:+.1f}B · {ratio(actual-prior,prior)}</span></div><div class="mini-pair"><span>2025</span><div class="mini-track"><i class="prior-fill" style="width:{prior/maximum*100:.2f}%"></i></div><b>{bn(prior)}B</b></div><div class="mini-pair"><span>2026</span><div class="mini-track"><i class="actual-fill" style="width:{actual/maximum*100:.2f}%"></i></div><b>{bn(actual)}B</b></div></div>')
        return '<div class="year-bars">' + ''.join(result) + '</div>'

    return {"BRAND_COMPARISON": table(brands, 'Brand'), "STAFF_COMPARISON": table(staff, 'Staff'),
            "BRAND_YEAR_CHART": year_bars(brands), "STAFF_YEAR_CHART": year_bars(staff),
            "PLAN_CHART": ''.join(plan_svg), "COMPARISON_DATA": json.dumps(cells).replace('<', '\\u003c'),
            "ANNUAL_TARGET": bn(totals['target_2026']), "TARGET_ATTAINMENT": ratio(totals['actual_2026'], totals['target_2026']),
            "ANNUAL_BUDGET_GAP": bn(totals['budget_2026'] - totals['actual_2026']),
            "ANNUAL_TARGET_GAP": bn(totals['target_2026'] - totals['actual_2026']),
            "YOY_DELTA": f'{(totals["actual_2026"]-totals["prior_2025"])/1e9:+.1f}'}, brands, staff, totals


def build():
    source_path = ROOT / "synthetic-inputs.json"
    if not source_path.exists():
        source_path.write_text(json.dumps(create_inputs(), indent=2), encoding="utf-8")
    source = json.loads(source_path.read_text(encoding="utf-8"))
    if 'comparison_cells' not in source['planning_assumptions']:
        source['planning_assumptions'].update(comparison_assumptions())
        source_path.write_text(json.dumps(source, indent=2), encoding='utf-8')
    records = normalize(source)
    assumptions = source["planning_assumptions"]
    months = aggregate(records, "Period")
    categories = aggregate(records, "Category")
    reps = aggregate(records, "Representative")
    groups = aggregate(records, "Customer group")
    total = sum(r["Sales excluding VAT"] for r in records)
    invoices = {r["Document ID"] for r in records}
    ytd_plan = sum(assumptions["monthly_budget"])
    prior = sum(assumptions["monthly_prior_comparison"])
    monthly_counts = {p: len({r["Document ID"] for r in records if r["Period"] == p}) for p in months}
    matrix = {(rep, cat): sum(r["Sales excluding VAT"] for r in records if r["Representative"] == rep and r["Category"] == cat) for rep in REPS for cat in CATEGORIES}
    comparison_cells = [dict(c, actual_2026=matrix[c['staff'], c['brand']]) for c in assumptions['comparison_cells']]
    comparison_html, brand_comparison, staff_comparison, comparison_totals = comparison_views(comparison_cells)
    checks = {
        "Unique line identifiers": len(records) == len({r["Line ID"] for r in records}),
        "Monthly sales match fictional controls": all(months[f"M{i + 1:02}"] == v for i, v in enumerate(assumptions["monthly_sales_controls"])),
        "Category totals reconcile to sales": sum(categories.values()) == total,
        "Representative totals reconcile to sales": sum(reps.values()) == total,
        "Customer group totals reconcile to sales": sum(groups.values()) == total,
        "Matrix rows reconcile to representatives": all(sum(matrix[rep, cat] for cat in CATEGORIES) == reps[rep] for rep in REPS),
        "Matrix columns reconcile to categories": all(sum(matrix[rep, cat] for rep in REPS) == categories[cat] for cat in CATEGORIES),
        "Category budgets reconcile to YTD budget": sum(assumptions["category_ytd_budget"].values()) == ytd_plan,
        "Invoice counts match fictional controls": list(monthly_counts.values()) == INVOICES,
        "Invoice attributes are consistent across lines": all(len({(r["Period"], r["Representative"], r["Customer group"]) for r in records if r["Document ID"] == doc}) == 1 for doc in invoices),
        "One comparison cell per staff and brand": len(comparison_cells) == len(matrix) and len({(c['staff'], c['brand']) for c in comparison_cells}) == len(matrix),
        "2025 YTD matrix reconciles to monthly prior sales": comparison_totals['prior_2025'] == prior,
        "2026 annual budget matrix reconciles to annual plan": comparison_totals['budget_2026'] == assumptions['annual_budget'],
        "2026 annual target matrix reconciles to annual target": comparison_totals['target_2026'] == assumptions['annual_target'],
        "2026 YTD matrix reconciles to source sales": comparison_totals['actual_2026'] == total,
        "Brand and staff comparison rollups reconcile": all(sum(v[k] for v in brand_comparison.values()) == sum(v[k] for v in staff_comparison.values()) == comparison_totals[k] for k in comparison_totals),
        "Year-on-year brand and staff movements reconcile": sum(v['actual_2026'] - v['prior_2025'] for v in brand_comparison.values()) == sum(v['actual_2026'] - v['prior_2025'] for v in staff_comparison.values()) == total - prior,
    }
    if not all(checks.values()):
        raise ValueError(f"Validation failed: {checks}")
    summary = {"notice": source["notice"], "sales_excluding_vat": total, "ytd_budget": ytd_plan,
               "annual_budget": assumptions["annual_budget"], "prior_comparison": prior,
               "line_count": len(records), "invoice_count": len(invoices),
               "monthly_sales": months, "monthly_invoice_counts": monthly_counts,
               "category_sales": categories, "representative_sales": reps, "customer_group_sales": groups,
               "comparison_totals": comparison_totals, "brand_comparison": brand_comparison,
               "staff_comparison": staff_comparison, "staff_brand_comparison": comparison_cells,
               "checks": checks}
    (ROOT / "validation.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    svg = ['<svg viewBox="0 0 950 330" role="img" aria-labelledby="trend-title trend-desc"><title id="trend-title">Synthetic monthly sales for 2025 and 2026 versus phased 2026 budget</title><desc id="trend-desc">January–September fictional 2025 sales, 2026 sales and phased 2026 budget in billion VND. The full numeric values are available in the table below.</desc>']
    for tick in [0, 5, 10, 15, 20]:
        y = 278 - tick * 11
        svg.append(f'<line class="gridline" x1="48" y1="{y}" x2="938" y2="{y}"/><text class="axis" x="33" y="{y + 4}" text-anchor="end">{tick}</text>')
    for i, (period, actual) in enumerate(months.items()):
        x = 67 + i * 98
        for dx, value, cls in [(0, actual, "actual-bar"), (27, assumptions["monthly_prior_comparison"][i], "prior-bar"), (54, assumptions["monthly_budget"][i], "plan-bar")]:
            height = value / 1e9 * 11
            svg.append(f'<rect class="{cls}" x="{x + dx}" y="{278 - height}" width="22" height="{height}" rx="3"><title>{period}: {bn(value)}B VND {dict(actual_bar="2026 sales", prior_bar="2025 sales", plan_bar="2026 phased budget")[cls.replace("-", "_")]}</title></rect>')
        svg.append(f'<text class="bar-label" x="{x + 12}" y="{278 - actual / 1e9 * 11 - 9}" text-anchor="middle">{bn(actual)}</text><text class="axis" x="{x + 26}" y="305" text-anchor="middle">{["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"][i]}</text>')
    svg.append('</svg>')
    monthly_rows = ''.join(f'<tr><th scope="row">{["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"][i]}</th><td>{bn(assumptions["monthly_prior_comparison"][i])}</td><td>{bn(v)}</td><td>{bn(assumptions["monthly_budget"][i])}</td><td>{(v-assumptions["monthly_prior_comparison"][i])/1e9:+.1f}</td><td>{pct(v/assumptions["monthly_prior_comparison"][i]-1)}</td><td>{monthly_counts[p]}</td><td>{v / monthly_counts[p] / 1e6:,.1f}</td></tr>' for i, (p, v) in enumerate(months.items()))
    cat_rows = ''.join(f'<tr><th scope="row">{c}</th><td>{bn(categories[c])}</td><td>{bn(assumptions["category_ytd_budget"][c])}</td><td>{(categories[c] - assumptions["category_ytd_budget"][c]) / 1e9:+.1f}</td><td>{pct(categories[c] / total)}</td></tr>' for c in CATEGORIES)
    heat_rows = ''
    max_cell = max(matrix.values())
    for rep in REPS:
        heat_rows += f'<tr><th scope="row">{display_label(rep)}</th>'
        for cat in CATEGORIES:
            value = matrix[rep, cat]
            alpha = .07 + .50 * value / max_cell
            heat_rows += f'<td style="background:rgba(36,177,177,{alpha:.3f})">{bn(value)}</td>'
        heat_rows += f'<td class="total-cell">{bn(reps[rep])}</td></tr>'
    heat_rows += '<tr class="total-row"><th scope="row">Total</th>' + ''.join(f'<td>{bn(categories[c])}</td>' for c in CATEGORIES) + f'<td>{bn(total)}</td></tr>'
    top_group, top_value = max(groups.items(), key=lambda x: x[1])
    first, last = list(months)[0], list(months)[-1]
    first_avg = Decimal(months[first]) / monthly_counts[first]
    last_avg = Decimal(months[last]) / monthly_counts[last]
    count_effect = Decimal(monthly_counts[last] - monthly_counts[first]) * first_avg
    value_effect = Decimal(monthly_counts[last]) * (last_avg - first_avg)
    replacements = {
        **comparison_html,
        'SALES': bn(total), 'YTD_PLAN': bn(ytd_plan), 'ANNUAL_PLAN': bn(assumptions['annual_budget']),
        'PRIOR': bn(prior), 'YOY': pct(total / prior - 1), 'VS_PLAN': pct(total / ytd_plan),
        'ANNUAL_ATTAINMENT': pct(total / assumptions['annual_budget']), 'PLAN_DELTA': f'{(total - ytd_plan) / 1e9:+.1f}',
        'LINE_COUNT': f'{len(records):,}', 'INVOICE_COUNT': f'{len(invoices):,}',
        'AVG_INVOICE': f'{total / len(invoices) / 1e6:,.1f}', 'CHART': ''.join(svg),
        'MONTHLY_ROWS': monthly_rows, 'CATEGORY_ROWS': cat_rows, 'HEAT_ROWS': heat_rows,
        'TOP_GROUP': top_group, 'GROUP_SHARE': pct(top_value / total),
        'COUNT_GROWTH': pct(monthly_counts[last] / monthly_counts[first] - 1),
        'AVG_GROWTH': pct(float(last_avg / first_avg - 1)),
        'FIRST_AVG': f'{first_avg / 1000000:.1f}', 'LAST_AVG': f'{last_avg / 1000000:.1f}',
        'COUNT_EFFECT': f'{count_effect / 1000000000:.2f}', 'VALUE_EFFECT': f'{value_effect / 1000000000:.2f}',
        'SALES_CHANGE': f'{(months[last] - months[first]) / 1e9:.2f}',
        'CHECKS': ''.join(f'<li><span class="pass">PASS</span> {html.escape(display_label(k)).replace("categories", "brands").replace("representatives", "staff")}</li>' for k in checks),
        'CHECK_COUNT': str(len(checks)),
    }
    template = (ROOT / 'page.template.html').read_text(encoding='utf-8')
    for key, value in replacements.items():
        template = template.replace('{{' + key + '}}', value)
    if '{{' in template:
        raise ValueError('Unresolved page placeholder')
    (ROOT / 'index.html').write_text(template, encoding='utf-8')
    # Explicit allowlist: only this independent demonstration is packaged.
    public_files = ['index.html', 'page.template.html', 'build_demo.py', 'synthetic-inputs.json', 'validation.json', 'README.md']
    with zipfile.ZipFile(ROOT / 'revenue-intelligence-v2-demo.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for name in public_files:
            z.write(ROOT / name, name)
    page_target = ROOT.parent.parent / 'projects' / 'revenue-intelligence-v2.html'
    if page_target.parent.exists():
        page_target.write_text(template.replace('href="revenue-intelligence-v2-demo.zip"', 'href="../portfolio-artifacts/06-commercial-revenue-intelligence-v2/revenue-intelligence-v2-demo.zip"'), encoding='utf-8')
    print(json.dumps({'sales_B': total / 1e9, 'lines': len(records), 'invoices': len(invoices), 'checks_passed': len(checks), 'page': str(page_target)}, indent=2))


if __name__ == '__main__':
    build()
