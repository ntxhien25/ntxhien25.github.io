# Commercial Revenue Intelligence — public demonstration, version 2

This standalone case study demonstrates schema normalization, sales reporting and reconciliation using independently generated fictional records. It contains no private workbook, scaled actual values, customer names, tax identifiers, employee initials, real product brands or project identifiers. January–September 2025 and 2026 are illustrative year labels, not actual corporate results. VND is the illustrative reporting currency. Source periods M01–M09 map to January–September in the displayed demonstration.

## Open and reproduce

Open `index.html` in a browser. No server, internet connection or installation is needed to view it. To rebuild, run `python build_demo.py` with Python 3. The builder uses only the standard library. It reads `synthetic-inputs.json`, validates the data and regenerates the page, validation report and ZIP. The ZIP uses an explicit six-file allowlist and does not include itself. In the original portfolio workspace it also writes the separate `projects/revenue-intelligence-v2.html` page. It never writes the earlier version.

To regenerate the original fictional inputs, remove only `synthetic-inputs.json` and rerun. Generation uses a fixed random seed and fixed fictional controls. The source data deliberately changes column order after M03 and M06, demonstrating mapping by header labels rather than column positions.

## Metric contract

- Grain: one sales line. Line IDs are unique. Several lines may share a document ID.
- Invoice count: distinct document IDs in this fixture, where each ID represents one fictional invoice. This equivalence must be validated separately for real source systems, including entity, invoice series and adjustment treatment.
- Sales: sum of `Sales excluding VAT`. VAT is separate and never enters sales. The fixture uses a fictional 8% VAT assumption solely to distinguish the fields; it is not tax guidance.
- Average invoice value: sales divided by distinct invoice IDs. This is not average line value or a physical product price.
- YTD attainment: nine-period sales divided by the corresponding phased nine-period budget. Full-year budget attainment uses the separately stated annual budget.
- Target 2026: the full-year unrealistic stretch ambition, set to a fictional 180B VND. Budget 2026: the full-year realistic operating plan, set to 120B VND. YTD 2026: real-sales metric for January–September, represented by 96B VND of synthetic transaction amounts in this public demo.
- Prior-period comparison: January–September 2025 fictional sales, supplied as aggregate assumptions of 78B VND; not a transactional backtest. Monthly prior figures and the prior staff–brand matrix each reconcile to this total. They do not assert a historical monthly staff–brand allocation.
- YoY discrepancy: YTD 2026 minus YTD 2025, for the same January–September period. Percentage change = discrepancy / YTD 2025. A zero denominator produces n.a. in the interactive matrix.
- Annual-plan gaps: full-year target/budget less YTD actual sales. Annual attainment = YTD actual sales / full-year plan, which is distinct from same-period phased YTD budget attainment. Do not interpret an annual-plan gap as a same-period operating variance or forecast.
- Source category labels and representative labels appear publicly as Brand A–F and Staff 01–05. They are generic fictional labels with no private identity mapping.
- Matrix: staff × brand sales, with both margins reconciled to the same line dataset. A measure selector switches among YTD 2025, YTD 2026, annual budget, annual target, YoY discrepancy, YoY percent change and annual-plan attainment percentages. Monetary values are integer VND; visual outputs round to 0.1B. Percentage totals are recomputed from summed numerators and denominators, never added or averaged. Staff filtering retains full-dataset reference totals.
- One comparison cube (`comparison_cells`) owns the fictional 2025 YTD and 2026 annual target/budget allocations. The builder adds 2026 YTD actuals from normalized sales. Brand tables, staff tables, year comparison bars and interactive matrix all use this cube, so their totals agree.
- Driver bridge: M09 sales minus M01 sales = (M09 invoice count − M01 invoice count) × M01 average invoice value + M09 invoice count × (M09 average invoice value − M01 average invoice value). This is an exact sequential bridge; the interaction is assigned to average invoice value. It is descriptive, not causal, and is not a price-volume-mix analysis.
- Category budgets, annual budget and monthly comparisons are fictional planning assumptions, not estimates of confidential performance. A remaining annual budget amount does not imply an annual forecast.

## Validation and limitations

The builder rejects missing or duplicate headers, malformed rows, missing required fields, mismatched periods, unmapped categories/representatives and non-integer monetary fields. `validation.json` records seventeen calculated checks, including unique lines, fictional monthly controls, dimensional totals, matrix margins, budget allocation, invoice counts, consistent invoice attributes, complete staff–brand comparisons, reconciliation of prior sales and annual plans, and agreement of brand/staff YoY movements. These checks apply to this synthetic fixture only; they do not establish reconciliation of any private workbook.

The public fixture has only positive sales, no duplicate corrections, returns, mixed currencies or cost data. Production work would require explicit policies and additional tests for those cases. Revenue patterns alone cannot establish seasonality, project milestones, price changes, profitability, collections or causality. Suggested actions are illustrative; no stakeholder adoption, time savings or business impact is claimed.

## File inventory

`index.html`: self-contained page with inline charts and browser controls. `page.template.html`: editable source. `build_demo.py`: normalization, aggregation, validation, generation and packaging. `synthetic-inputs.json`: fictional source sheets and planning assumptions. `validation.json`: calculated metrics and checks. No trackers are used. Optional Google Fonts match the existing portfolio typography; system font fallbacks keep the page readable offline. Portfolio navigation opens the public website.
